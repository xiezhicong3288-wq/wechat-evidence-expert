# chat-evidence

微信聊天记录→证据级整理(自我进化/图尔敏论证/司法锚定)。仅本地、不篡改、可溯源。

## 安装

放到 skills 目录（项目级 `.workbuddy/skills/chat-evidence/` 或用户级 skills 目录）即可，无需依赖，仅用 Python 标准库。

## 用法

```bash
# 证据链（一条龙）
python scripts/main.py --export 导出.json --identity idmap.json all
# 图尔敏论证结构（可选传主张清单）
python scripts/main.py --export 导出.json --claims 主张.json toulmin
# 自我进化：记录经验 / 晋升规则 / 回归检测
python scripts/main.py reflect --kind worked --note "..."
python scripts/main.py learn --rule "..." --reasoning "..."
python scripts/main.py regress --export 导出.json
```

证据产物写到导出文件同目录：`*.anchor.json`、`*.evidence_index.json`、`*.timeline.md`、`*.toulmin.md`、`*.identity.md`。进化日志在 `vault/`，晋升规则在 `rules/`。退出码非 0 表示失败。

此外支持**多角色对抗推演**：把证据产物喂给「顶尖律师团队 / 公安 / 法院 / 当地政府 / 上级监督部门」五个独立立场做交叉质证与博弈预演，输出《运筹决策报告》。提示词与规则见 `references/multi_role_sandbox.md`。

## 运行环境

Python 3.8+，纯标准库，离线可用，无网络依赖。

## 许可

MIT。方法论借鉴自：图尔敏论证模型（Toulmin）、最高法《互联网法院规定》第11条电子数据真实性审查、self-improving-agent 的复合回路与分层记忆晋升。
