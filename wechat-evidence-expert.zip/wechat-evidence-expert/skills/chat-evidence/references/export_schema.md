# 导出格式（chat-evidence 输入）

本 skill 读取一个 JSON 文件，结构如下（兼容 weixin-liaotianjilu-skill 的导出约定并扩展 identity 字段）：

```json
{
  "chat": "会话/群名称",
  "username": "会话id",
  "exported_at": "2026-01-01T00:00:00Z",
  "is_group": true,
  "messages": [
    {
      "timestamp": 1735689600,
      "sender": "展示昵称",
      "sender_id": "wxid_xxxx（可选，用于身份印证）",
      "type": "text",
      "content": "文字内容",
      "extra": {}
    },
    {
      "timestamp": 1735690000,
      "sender": "对方",
      "sender_id": "wxid_yyyy",
      "type": "transfer",
      "content": "",
      "extra": {"amount": 50000, "desc": "项目首付款"}
    }
  ]
}
```

## 字段说明

- `timestamp`：Unix 秒级时间戳（UTC 或本地均可，工具只排序与展示）。
- `sender` / `sender_id`：`sender_id` 优先用于身份映射与去重；无则退回 `sender`。
- `type`：text / image / voice / video / file / transfer / system。非 text 类型，`content` 可为空，由 `msg_text()` 生成占位摘要。
- `extra.amount`：转账金额（数值），用于金额/转账事实清单汇总。

## 关于解密导出（本 skill 不负责）

微信数据需先解密，推荐路径 A：用微信官方"恢复"把备份还原到同账号手机 → 再经官方导出或留痕/WeFlow 导出为上述 JSON。
