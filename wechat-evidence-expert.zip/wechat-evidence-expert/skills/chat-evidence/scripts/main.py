#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""chat-evidence: 微信聊天记录 → 证据级整理 + 自我进化 skill。

证据铁律（不可破坏）：
  - 只读取导出文件，绝不修改、删除、外传原始数据。
  - 只归类、不篡改：所有输出引用原文(msg_id)而非改写。
  - 全程本地，不调用外部服务或上传聊天内容。
  - 不替用户做法律判断，结论由律师定稿。

子命令（证据链）：
  validate   校验导出文件结构（不打印私人聊天内容）
  anchor     生成完整性哈希锚定 + 可信时间戳标记 + 入链前声明
  extract    抽取法律语义要素（合同/承诺/金额/转账/验收/违约…）
  timeline   生成时间线 + 金额清单
  toulmin    生成图尔敏论证结构（主张/根据/保证/支撑/限定/反驳）
  identity   生成身份印证链
  all        依次执行上述全部

子命令（自我进化，见 references/evolution_architecture.md）：
  reflect    捕获"可教时刻"，写入 vault/learnings 与 corrections
  learn      评估并晋升经验为强制规则（阶2，走质量门）
  regress    回归检测：对比基线，防止升级退化（阶3 前必跑）
  promote    把成熟流程沉淀为子 skill 骨架（阶3，需审批）
"""
import argparse
import hashlib
import json
import os
import re
import sys
from datetime import datetime, timezone

EXPORT_SCHEMA_VERSION = "1.1"
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VAULT = os.path.join(SKILL_DIR, "vault")
LEARNINGS = os.path.join(VAULT, "learnings")
HISTORY = os.path.join(VAULT, "config-history")
BASELINES = os.path.join(VAULT, "baselines")
RULES_DIR = os.path.join(SKILL_DIR, "rules")

# 法律语义要素分类规则（关键词 → 类别）。仅粗筛，命中后需人工复核。
CATEGORY_RULES = {
    "合同协议": ["合同", "协议", "签约", "约定", "条款", "起草", "书面", "盖章", "签署", "意向书", "框架"],
    "承诺确认": ["承诺", "保证", "确认", "没问题", "可以", "同意", "负责", "包在", "一定", "收到", "好的", "明白"],
    "金额价格": ["元", "万", "费用", "价格", "报价", "金额", "付款", "收款", "结算", "欠款", "尾款", "定金", "总价", "预付款", "首付款"],
    "转账支付": ["转账", "支付", "打款", "汇款", "收款码", "支付宝", "微信支付", "发票"],
    "验收交付": ["验收", "交付", "交货", "完工", "合格", "交付标准", "进度", "节点", "进场", "施工", "完工"],
    "违约责任": ["违约", "逾期", "延期", "赔偿", "责任", "纠纷", "起诉", "投诉", "未按", "拖延", "追究", "返工"],
    "期限时间": ["截止", "期限", "之前完成", "日内", "月底前", "周", "前", "工期", "交付期", "延期"],
    "质量标准": ["质量", "标准", "规格", "不合格", "返工", "检测", "验收标准", "国标"],
}

AMBIGUOUS = {"可以", "没问题", "好的", "收到", "同意", "明白"}  # 短确认需人工复核


def load_export(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict) or "messages" not in data:
        raise SystemExit("导出文件缺少 messages 字段，不符合 chat-evidence 导出格式")
    return data


def msg_text(m):
    t = m.get("type", "text")
    if t == "text":
        return m.get("content", "") or ""
    if t == "transfer":
        return "[转账] " + str(m.get("extra", {}).get("amount", ""))
    if t == "image":
        return "[图片] " + (m.get("extra", {}).get("desc", "") or "")
    return "[" + t + "]"


def ts_to_iso(ts):
    try:
        return datetime.fromtimestamp(int(ts), tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    except Exception:
        return str(ts)


def ensure_dir(d):
    os.makedirs(d, exist_ok=True)


def now_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def categorize(text):
    cats = []
    for cat, kws in CATEGORY_RULES.items():
        if any(kw in text for kw in kws):
            cats.append(cat)
    return cats


def _rows(data):
    rows = []
    for i, m in enumerate(data["messages"]):
        text = msg_text(m)
        cats = categorize(text)
        if m.get("type") == "transfer":
            cats.append("转账支付")
        rows.append({
            "idx": i,
            "ts": m.get("timestamp"),
            "iso": ts_to_iso(m.get("timestamp")) if isinstance(m.get("timestamp"), (int, float)) else "?",
            "sender": m.get("sender"),
            "sender_id": m.get("sender_id") or m.get("sender"),
            "type": m.get("type", "text"),
            "cats": cats,
            "text": text,
            "amount": m.get("extra", {}).get("amount") if m.get("type") == "transfer" else None,
        })
    return rows


def cmd_validate(args):
    data = load_export(args.export)
    msgs = data["messages"]
    senders, types, tmin, tmax = {}, {}, None, None
    for m in msgs:
        s = m.get("sender", "未知")
        senders[s] = senders.get(s, 0) + 1
        ty = m.get("type", "text")
        types[ty] = types.get(ty, 0) + 1
        ts = m.get("timestamp")
        if isinstance(ts, (int, float)):
            tmin = ts if tmin is None else min(tmin, ts)
            tmax = ts if tmax is None else max(tmax, ts)
    print("校验通过：导出文件结构合法")
    print("会话：%s（%s）" % (data.get("chat", "?"), "群聊" if data.get("is_group") else "单聊"))
    print("消息总数：%d" % len(msgs))
    print("日期范围：%s ~ %s" % (ts_to_iso(tmin) if tmin else "?", ts_to_iso(tmax) if tmax else "?"))
    print("发言人分布：%s" % "、".join("%s:%d" % (k, v) for k, v in sorted(senders.items(), key=lambda x: -x[1])))
    print("类型分布：%s" % "、".join("%s:%d" % (k, v) for k, v in sorted(types.items(), key=lambda x: -x[1])))
    return 0


def cmd_anchor(args):
    data = load_export(args.export)
    msgs = data["messages"]
    manifest = {
        "schema": EXPORT_SCHEMA_VERSION,
        "chat": data.get("chat"),
        "exported_at": data.get("exported_at"),
        "message_count": len(msgs),
        "anchored_at": now_iso(),
        "file_sha256": hashlib.sha256(open(args.export, "rb").read()).hexdigest(),
        # 司法真实性锚定（对齐最高法《互联网法院规定》第11条 + 电子数据真实性审查）
        "trusted_timestamp": {
            "status": "pending",  # 由可信时间戳服务（如联合信任/权利卫士）签发后改为 issued
            "service": "待接入可信时间戳服务（司法认可第三方）",
            "note": "哈希+可信时间戳+入链前清洁性声明，三件套共同证明真实性",
        },
        "pre_chain_declaration": {
            "clean_env": True,
            "source": "微信官方导出（路径A）",
            "statement": "声明：本导出取自微信官方通道，未做任何删改；导出后立即锚定。",
            "note": "入链前真实性是入链后真实性的基础（杭州互联网法院审查要点）",
        },
        "messages": [],
    }
    chain = hashlib.sha256()
    for i, m in enumerate(msgs):
        canonical = json.dumps(m, ensure_ascii=False, sort_keys=True)
        h = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        chain.update(h.encode("utf-8"))
        manifest["messages"].append({"idx": i, "msg_sha256": h})
    manifest["chain_sha256"] = chain.hexdigest()
    out = args.out or (os.path.splitext(args.export)[0] + ".anchor.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print("完整性锚定已生成：%s" % out)
    print("文件指纹(file_sha256)：%s" % manifest["file_sha256"])
    print("链式指纹(chain_sha256)：%s" % manifest["chain_sha256"])
    print("可信时间戳：待接入司法认可第三方服务后签发（当前 status=pending）")
    print("入链前声明：已记录（微信官方导出、未删改、导出即锚定）")
    print("消息 %d 条——任何后续改动都会改变指纹，可当庭比对证明未剪辑" % len(msgs))
    return 0


def cmd_extract(args):
    data = load_export(args.export)
    index = []
    for i, m in enumerate(data["messages"]):
        text = msg_text(m)
        cats = categorize(text)
        if m.get("type") == "transfer":
            cats.append("转账支付")
        if not cats:
            continue
        need_review = bool(AMBIGUOUS & set(text.strip()))
        index.append({
            "idx": i, "ts": m.get("timestamp"), "sender": m.get("sender"),
            "categories": cats, "snippet": text[:120], "need_review": need_review,
        })
    out = args.out or (os.path.splitext(args.export)[0] + ".evidence_index.json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)
    print("法律要素抽取完成：命中 %d 条" % len(index))
    print("输出：%s" % out)
    cat_count = {}
    for it in index:
        for c in it["categories"]:
            cat_count[c] = cat_count.get(c, 0) + 1
    print("类别分布：%s" % "、".join("%s:%d" % (k, v) for k, v in sorted(cat_count.items(), key=lambda x: -x[1])))
    flagged = [it for it in index if it["need_review"]]
    if flagged:
        print("⚠ %d 条短确认(如'可以/没问题/好的')需人工复核语义，勿直接作承诺证据" % len(flagged))
    return 0


def cmd_timeline(args):
    data = load_export(args.export)
    rows = _rows(data)
    rows.sort(key=lambda r: r["ts"] if isinstance(r["ts"], (int, float)) else 0)
    md = ["# 微信聊天记录时间线（证据草稿）\n",
          "会话：%s（%s）\n" % (data.get("chat", "?"), "群聊" if data.get("is_group") else "单聊"),
          "## 一、按时间排序的关键记录\n",
          "| # | 时间(UTC) | 发言人 | 类别 | 内容摘要 |",
          "| --- | --- | --- | --- | --- |"]
    for r in rows:
        if r["cats"]:
            snippet = re.sub(r"\s+", " ", r["text"])[:60]
            md.append("| %d | %s | %s | %s | %s |" % (r["idx"], r["iso"], r["sender"], "/".join(r["cats"]), snippet))
    md += ["\n## 二、金额/转账事实清单（供诉讼/谈判核验）\n"]
    amounts = [r for r in rows if r["amount"] or "转账支付" in r["cats"] or "金额价格" in r["cats"]]
    if amounts:
        md += ["| # | 时间 | 发言人 | 金额/说明 |", "| --- | --- | --- | --- |"]
        for r in amounts:
            md.append("| %d | %s | %s | %s |" % (r["idx"], r["iso"], r["sender"], r["amount"] if r["amount"] else "见内容"))
    else:
        md.append("（本导出未发现明确金额/转账标记，请结合微信官方电子支付凭证补全）\n")
    out = args.out or (os.path.splitext(args.export)[0] + ".timeline.md")
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    print("时间线已生成：%s" % out)
    print("含法律要素的关键记录 %d 条；金额/转账相关 %d 条" % (sum(1 for r in rows if r["cats"]), len(amounts)))
    return 0


def cmd_toulmin(args):
    """图尔敏论证结构：主张/根据/保证/支撑/限定/反驳。"""
    data = load_export(args.export)
    rows = _rows(data)
    claims = []
    if args.claims:
        with open(args.claims, "r", encoding="utf-8") as f:
            claims = json.load(f)
    md = ["# 图尔敏论证结构（证据链）\n",
          "会话：%s\n" % data.get("chat", "?"),
          "> 六要素：主张(Claim) / 根据(Ground) / 保证(Warrant) / 支撑(Backing) / 限定(Qualifier) / 反驳(Rebuttal)。",
          "> 由律师定稿；本工具只把证据归位到要素，不做价值判断。\n"]
    if not claims:
        md += ["（未提供 claims.json，以下为证据池，供律师挑选归位）\n", "## 证据池（按要素粗筛）\n"]
        md += ["| # | 时间 | 发言人 | 内容 | 可归位要素 |", "| --- | --- | --- | --- | --- |"]
        for r in rows:
            if not r["cats"]:
                continue
            snippet = re.sub(r"\s+", " ", r["text"])[:50]
            md.append("| %d | %s | %s | %s | %s |" % (r["idx"], r["iso"], r["sender"], snippet, "/".join(r["cats"])))
    else:
        for c in claims:
            md.append("## 主张：%s\n" % c.get("claim", "?"))
            md.append("- **根据(Ground)**：%s" % "、".join(c.get("ground_msg_ids", [])) or "待补")
            md.append("- **保证(Warrant)**：%s" % c.get("warrant", "待补：为何这些事实能推出该主张"))
            md.append("- **支撑(Backing)**：%s" % c.get("backing", "待补：法律条文/合同条款/官方凭证等更强依据"))
            md.append("- **限定(Qualifier)**：%s" % c.get("qualifier", "待补：如'很可能/按现有证据/除非有相反证据'"))
            md.append("- **反驳(Rebuttal)**：%s" % c.get("rebuttal", "待补：对方可能提出的相反主张及应对"))
            md.append("")
    out = args.out or (os.path.splitext(args.export)[0] + ".toulmin.md")
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    print("图尔敏论证结构已生成：%s" % out)
    print("提示：六要素中 主张/根据/保证 为必备，其余按需；请律师据此定稿。")
    return 0


def cmd_identity(args):
    data = load_export(args.export)
    idmap = {}
    if args.identity:
        with open(args.identity, "r", encoding="utf-8") as f:
            idmap = json.load(f)
    senders = {}
    for m in data["messages"]:
        sid = m.get("sender_id") or m.get("sender")
        senders.setdefault(sid, {"display": m.get("sender"), "count": 0})
        senders[sid]["count"] += 1
    md = ["# 身份印证链（草图）\n", "| 标识 | 出现次数 | 实名 | 手机号 | 所属方 | 状态 |",
          "| --- | --- | --- | --- | --- | --- |"]
    for sid, info in sorted(senders.items(), key=lambda x: -x[1]["count"]):
        meta = idmap.get(sid, {})
        missing = [k for k in ("real_name", "phone", "org") if not meta.get(k)]
        status = "已印证" if not missing else "缺" + "/".join(missing)
        md.append("| %s | %d | %s | %s | %s | %s |" % (
            sid, info["count"], meta.get("real_name", "—"), meta.get("phone", "—"), meta.get("org", "—"), status))
    md.append("\n提示：法院要求证明'这个微信号就是那个人/那家公司'。")
    md.append("请补全 identity_map.json，并尽量提供微信官方凭证交叉印证。\n")
    out = args.out or (os.path.splitext(args.export)[0] + ".identity.md")
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(md))
    print("身份印证链已生成：%s" % out)
    print("参与者 %d 人；请在 identity_map.json 补全缺口以形成完整印证。" % len(senders))
    return 0


# ───────────────────── 自我进化运行时 ─────────────────────

def _append_log(path, entry):
    ensure_dir(os.path.dirname(path))
    with open(path, "a", encoding="utf-8") as f:
        f.write(entry + "\n")


def cmd_reflect(args):
    """阶1：捕获可教时刻。"""
    kind = args.kind  # worked / failed / correction
    note = args.note
    ts = now_iso()
    if kind == "correction":
        _append_log(os.path.join(VAULT, "corrections.md"), "- [%s] %s" % (ts, note))
        print("已记录纠正 → vault/corrections.md")
    else:
        fn = "what-worked.md" if kind == "worked" else "what-failed.md"
        _append_log(os.path.join(LEARNINGS, fn), "- [%s] %s" % (ts, note))
        print("已记录%s → vault/learnings/%s" % ("经验" if kind == "worked" else "失败", fn))
    print("提示：经验需复现 ≥3 次且过质量门，才会晋升为强制规则（见 learn）。")
    return 0


def cmd_learn(args):
    """阶2：晋升经验为规则（走质量门）。"""
    ensure_dir(RULES_DIR)
    rule = {
        "rule": args.rule,
        "reasoning": args.reasoning,
        "promoted_at": now_iso(),
        "status": "proposed",  # 待人工审批后才转 active
    }
    # 质量门（本地提示，最终由用户确认）
    print("质量门自检：")
    print("  1) 是否真改进？ 2) 能否跨任务复用？ 3) 够具体？ 4) 够通用？ 5) 是否触碰证据铁律？")
    slug = re.sub(r"[^0-9a-zA-Z\u4e00-\u9fff]+", "_", args.rule)[:30]
    path = os.path.join(RULES_DIR, slug + ".json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rule, f, ensure_ascii=False, indent=2)
    _append_log(os.path.join(HISTORY, datetime.now().strftime("%Y-%m-%d") + ".md"),
                "- [%s] 提议规则：%s（status=proposed，待审批）" % (now_iso(), args.rule))
    print("已起草规则（待审批）：%s" % path)
    print("理由：%s" % args.reasoning)
    print("⚠ 规则 status=proposed，未经人工审批不会生效；审批后请将其改为 active。")
    return 0


def cmd_regress(args):
    """阶3前：回归检测。对比基线，防止升级退化。"""
    data = load_export(args.export)
    rows = _rows(data)
    current = {}
    for r in rows:
        for c in r["cats"]:
            current[c] = current.get(c, 0) + 1
    ensure_dir(BASELINES)
    base_path = os.path.join(BASELINES, "baseline.json")
    if os.path.exists(base_path):
        with open(base_path, "r", encoding="utf-8") as f:
            base = json.load(f)
        print("回归检测：基线 vs 当前（类别命中数）")
        all_cats = sorted(set(list(base.keys()) + list(current.keys())))
        regressed = []
        for c in all_cats:
            b, n = base.get(c, 0), current.get(c, 0)
            flag = ""
            if b > 0 and n == 0:
                flag = " ⚠ 骤降为0，疑似退化"
                regressed.append(c)
            elif n < b * 0.5:
                flag = " ⚠ 下降过半，关注"
                regressed.append(c)
            print("  %s：%d → %d%s" % (c, b, n, flag))
        if regressed:
            print("⚠ 发现退化类别：%s。建议回滚最近一次规则变更。" % "、".join(regressed))
            return 1
        print("回归通过：无显著退化。")
    else:
        with open(base_path, "w", encoding="utf-8") as f:
            json.dump(current, f, ensure_ascii=False, indent=2)
        print("首次运行：已建立基线 vault/baselines/baseline.json（当前命中数快照）")
        print("后续升级后请重跑 regress 做对比。")
    return 0


def cmd_all(args):
    for fn in (cmd_anchor, cmd_validate, cmd_extract, cmd_timeline, cmd_toulmin, cmd_identity):
        print("\n=== %s ===" % fn.__name__.replace("cmd_", ""))
        rc = fn(args)
        if rc:
            return rc
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="chat-evidence", description="微信聊天记录 → 证据级整理 + 自我进化")
    p.add_argument("--export", help="已解密的聊天记录导出 JSON 路径（只读）")
    p.add_argument("--out", help="输出路径（默认同目录生成）")
    p.add_argument("--identity", help="身份映射 JSON（可选）")
    p.add_argument("--claims", help="主张清单 JSON（toulmin 用，可选）")
    sub = p.add_subparsers(dest="cmd")

    # 证据链
    for name, fn in [("validate", cmd_validate), ("anchor", cmd_anchor), ("extract", cmd_extract),
                     ("timeline", cmd_timeline), ("toulmin", cmd_toulmin), ("identity", cmd_identity),
                     ("all", cmd_all)]:
        sp = sub.add_parser(name)
        sp.set_defaults(func=fn)
    # 自我进化
    sp = sub.add_parser("reflect")
    sp.add_argument("--kind", choices=["worked", "failed", "correction"], required=True)
    sp.add_argument("--note", required=True)
    sp.set_defaults(func=cmd_reflect)
    sp = sub.add_parser("learn")
    sp.add_argument("--rule", required=True)
    sp.add_argument("--reasoning", required=True)
    sp.set_defaults(func=cmd_learn)
    sp = sub.add_parser("regress")
    sp.add_argument("--export", help="导出 JSON 路径（用于计算当前类别命中）")
    sp.set_defaults(func=cmd_regress)

    args = p.parse_args(argv)
    if args.cmd in ("reflect", "learn") and not args.export:
        pass  # 进化命令不强依赖 export
    elif args.cmd != "regress" or (args.cmd == "regress" and args.export):
        if not args.export and args.cmd not in ("reflect", "learn"):
            p.error("该命令需要 --export")
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
