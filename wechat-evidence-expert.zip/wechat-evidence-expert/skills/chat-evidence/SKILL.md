---
name: chat-evidence
description: "将已解密的微信聊天记录导出(JSON)整理为诉讼/谈判可用的证据材料，并随使用自我迭代进化。能力：完整性哈希锚定+可信时间戳+入链前声明、时间线、角色名单、法律要素(合同/承诺/金额/转账/验收/违约)抽取、图尔敏论证结构(主张/根据/保证/支撑/限定/反驳)、身份印证链；自我进化：反思日志→经验晋升为规则→沉淀为子skill，含回归检测。仅本地、不篡改原文、可溯源。用于微信证据整理、聊天记录举证、证据索引、时间线、谈判材料、与政府及职能部门对接。"
description_zh: "微信聊天记录→证据级整理(自我进化/图尔敏论证/司法锚定)"
description_en: "Self-evolving WeChat chat evidence skill: Toulmin argumentation, judicial anchoring, legal fact extraction"
---

# 微信聊天记录证据级整理（自我进化）

把已解密的微信聊天记录导出(JSON)整理为诉讼/谈判可用的证据材料；只归类、不篡改、可溯源；并在使用中**自我迭代**（反思→晋升→沉淀）。

## 何时使用

用户需把微信聊天记录用于：诉讼举证、谈判施压、与政府/职能部门对接谈判，希望产出时间线、角色名单、法律要素索引、图尔敏论证结构、身份印证链。本 skill 只处理**已解密的导出 JSON**，不负责解密（解密走官方"恢复"或留痕/WeFlow）。

## 多角色对抗推演（上层能力面）

证据整理之后，可启动**五方立场推演沙盘**——顶尖律师团队 / 公安 / 法院 / 当地政府 / 上级监督部门五个独立角色，
基于同一份证据底本交叉质证、博弈预演，输出《运筹决策报告》（上/中/下策 + 合法依据 + 风险提示 + 破局点），
实现"全维度运筹、步步为赢"。完整提示词与总控推演规则见 [references/multi_role_sandbox.md](references/multi_role_sandbox.md)。

触发词：多角色分析、立场推演、对抗推演、律师/公安/法院/政府/监督视角、运筹决策、博弈沙盘、怎么施压/怎么推动解决。

**合规铁律（违反即中止）**：只推演依法依规路径；"施压"仅限纪委监委举报、行政复议、行政诉讼、媒体监督、人大政协、信访等法定监督渠道，且须真实有据；禁止设计捏造材料、诬告陷害、舆论裹挟司法、贿赂等违法手段；结论由律师定稿，不替用户下法律结论。

## 输入与格式

读取导出 JSON，字段见 [references/export_schema.md](references/export_schema.md)。关键字段：`chat`、`is_group`、`messages[].timestamp/sender/sender_id/type/content/extra`；转账 `type=transfer` 且 `extra.amount` 填金额。

## 命令映射

| 用户说 | 运行 |
| --- | --- |
| 校验导出文件 | `python scripts/main.py --export <文件> validate` |
| 生成司法完整性锚定 | `python scripts/main.py --export <文件> anchor` |
| 抽取法律要素 | `python scripts/main.py --export <文件> extract` |
| 生成时间线 | `python scripts/main.py --export <文件> timeline` |
| 图尔敏论证结构 | `python scripts/main.py --export <文件> --claims 主张.json toulmin` |
| 身份印证链 | `python scripts/main.py --export <文件> --identity idmap.json identity` |
| 全部执行 | `python scripts/main.py --export <文件> --identity idmap.json all` |
| 记录可教时刻 | `python scripts/main.py reflect --kind worked/failed/correction --note "..."` |
| 晋升经验为规则 | `python scripts/main.py learn --rule "..." --reasoning "..."` |
| 回归检测 | `python scripts/main.py regress --export <文件>` |

## 证据链工作流

1. **anchor（先验真）**：SHA-256 锚定 + 可信时间戳标记 + 入链前声明，对齐最高法《互联网法院规定》第11条与电子数据真实性审查（"入链前"真实性是"入链后"的基础）。产出 `*.anchor.json`。
2. **validate**：消息数、日期范围、发言人/类型分布；不打印原文。
3. **extract**：粗筛归类 合同协议/承诺确认/金额价格/转账支付/验收交付/违约责任/期限时间/质量标准；短确认标记 `need_review`，不臆造。
4. **timeline**：时间排序关键记录 + 金额/转账事实清单（`*.timeline.md`）。
5. **toulmin**：图尔敏六要素论证结构（主张/根据/保证/支撑/限定/反驳），供律师归位定稿（`*.toulmin.md`）。
6. **identity**：结合 `identity_map.json` 列参与者与印证缺口（`*.identity.md`）。

## 自我进化循环（三阶）

详见 [references/evolution_architecture.md](references/evolution_architecture.md)。核心：

- **阶1 reflect**：每次任务后捕获"可教时刻"→ `vault/learnings/` 与 `vault/corrections.md`（自动）。
- **阶2 learn**：经验复现 ≥3 次且过**质量门**（真改进/可复用/够具体/够通用/不触证据铁律）→ 起草 `rules/*.json`（status=proposed，**待人工审批**改 active 才生效）。
- **阶3 沉淀**：成熟流程 → 拆独立子 skill（需审批）。
- **regress**：每次升级后用锚定样本对比基线命中，防退化，异常即回滚。

## 读取结果

证据链产物写到导出文件同目录（`--out` 指定）。`anchor` 指纹、`extract` 类别分布、`toulmin` 论证结构、`timeline` 金额清单是举证核心素材。

## 失败处理

- 缺 `messages` 字段 → 报错停止，说明格式不符。
- 找不到导出文件 → 报错，请用户先解密导出（路径 A）。
- 出现 `need_review` → 提示人工复核，不替用户下法律结论。
- regress 报退化 → 回滚最近一次规则变更后再处理。

## Invariants（不可破坏）

- 仅读取导出文件，绝不修改、删除、外传原始数据。
- 只归类不篡改：输出引用原文(msg_id)而非改写。
- 进化只改"识别/论证规则"，**绝不触碰原始聊天内容与哈希锚定**。
- 不替用户做法律判断；结论由律师定稿。
- 全程本地，不调用外部服务或上传聊天内容。
- 多角色推演只输出依法依规路径，禁止任何违法/越界手段（详见 references/multi_role_sandbox.md 第 5 节）。
