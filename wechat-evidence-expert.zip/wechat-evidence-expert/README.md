# 微信证据整理专家（铁证 / Ironclad）

一句话：把已解密的微信聊天记录导出（JSON）整理为诉讼举证、谈判施压、政府及职能部门对接可用的**可采信证据材料**，并在使用中**自我进化**（越用越准、记忆持久）。

## 类型
Agent 型（单个 AI 专家），行业分类：法务安全（11-SecurityCompliance）。

## 核心能力
- **司法完整性锚定**：SHA-256 文件指纹 + 链式指纹 + 可信时间戳标记 + 入链前清洁性声明，对齐最高法《互联网法院规定》第11条。
- **法律要素抽取 + 时间线**：合同/承诺/金额/转账/验收/违约/期限/质量八类，金额与转账事实清单。
- **图尔敏论证结构**：主张/根据/保证/支撑/限定/反驳六要素，供律师定稿。
- **身份印证链**：证明"这个微信号就是那个人/那家公司"。
- **五方立场推演（运筹）**：律师/公安/法院/政府/监督五方视角，仅输出依法路径。
- **自我进化（带记忆）**：反思日志→经验晋升为规则→沉淀为子 skill，含回归检测；记忆落在用户级持久目录，跨会话/跨项目复用。

## 内置 Skill
本专家内嵌 `skills/chat-evidence`——完整的证据整理与自我进化脚本（脚本、参考文档、合成样本均随包携带）。

## 召唤方式
在 WorkBuddy 专家中心搜索「铁证」或「微信证据整理专家」，一键召唤。首次对话可直接发送：
> 整理这份微信聊天记录导出，生成证据时间线、身份印证链和图尔敏论证结构

## 使用示例
- 整理微信聊天记录导出为证据时间线、身份印证链、图尔敏论证链
- 用图尔敏模型把关键事实组织成可提交的证据论证结构
- 对证据做五方立场推演，给出谈判与破局策略

## 头像
⚠️ 当前缺头像（`avatars/expert.png`）。可手动放置 PNG/JPG（512×512，≤500KB），或运行以下推荐 prompt 通过 ImageGen 生成：
> Professional cartoon-style illustration avatar, a meticulous and trustworthy digital forensics evidence specialist, wearing smart professional attire with subtle round glasses, holding a shield-shaped document marked with a hash-lock symbol, analytical confident expression, faint scales of justice and chat-bubble evidence icons floating in the background. Bust shot, facing forward. Clean simple dark grey-blue-toned background. High quality, professional, natural.

## 安装 / 注册
专家已注册到 `marketplace.json`，WorkBuddy 专家中心可见、可直接召唤。如需迁移到其它机器，将本目录整体拷贝到目标机的 `~/.workbuddy/plugins/marketplaces/my-experts/plugins/` 后重跑：
```bash
python scripts/register_expert.py <expert-dir>
```

## 合规铁律（违反即中止）
- 仅读取导出文件，绝不修改/删除/外传原始数据；全程本地，不上云。
- 只归类不篡改，结论回引 msg_id；法律结论由律师定稿。
- 进化只改识别/论证规则，绝不触碰原始聊天内容与哈希锚定。
- 五方推演只输出法定监督渠道，禁止捏造、诬告、贿赂、裹挟司法。
